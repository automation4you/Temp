param($Request, $TriggerMetadata)

# Use environment variables for secrets
$expectedSecret = $env:SECRET.Trim()  # Trim whitespace
$githubWebhookUrl = $env:GITHUB_URL
$githubToken = $env:GITHUB_TOKEN

# Retrieve the secret from the headers
$receivedSecret = $Request.Headers["form-signature"].Trim()  # Trim whitespace

# Log both values for debugging
#Write-Host "Received Secret: '$receivedSecret'"
#Write-Host "Expected Secret: '$expectedSecret'"

# Verify the secret
if ($receivedSecret -ne $expectedSecret) {
    Write-Host "Unauthorized request: Invalid secret"
    $Response = @{
        StatusCode = 401
        Body = '{"status":"unauthorized"}'
        Headers = @{"Content-Type" = "application/json"}
    }
    return $Response
}

# Log the raw body
Write-Host "Raw Body: $($Request.Body | ConvertTo-Json -Depth 10)"

try {
    # Parse JSON from request body
    if ($Request.Body -is [Hashtable]) {
        $formData = $Request.Body
    } else {
        $rawBody = $Request.Body.ReadToEnd()
        $formData = $rawBody | ConvertFrom-Json
    }

    # Log parsed JSON
    Write-Host "Parsed JSON: $($formData | ConvertTo-Json -Depth 10)"

    # Extract variables from the request data
    $provider_vsphere_host = $formData.provider_vsphere_host
    $deploy_vsphere_datacenter = $formData.deploy_vsphere_datacenter
    $deploy_vsphere_cluster = $formData.deploy_vsphere_cluster
    $deploy_vsphere_datastore = $formData.deploy_vsphere_datastore
    $deploy_vsphere_network = $formData.deploy_vsphere_network
    $deploy_vsphere_folder = $formData.deploy_vsphere_folder
    $guest_template = $formData.guest_template
    $guest_vm_name = $formData.guest_vm_name
    $vsphere_vm_firmware = $formData.vsphere_vm_firmware
    $guest_vcpu = $formData.guest_vcpu
    $guest_memory = $formData.guest_memory
    $guest_ipv4_addr = $formData.guest_ipv4_addr
    $guest_ipv4_netmask = $formData.guest_ipv4_netmask
    $guest_ipv4_gateway = $formData.guest_ipv4_gateway
    $guest_dns_servers = $formData.guest_dns_servers
    $guest_dns_servers2 = $formData.guest_dns_servers2
    $guest_dns_suffix = $formData.guest_dns_suffix
    $vsphere_tag_env_name = $formData.vsphere_tag_env_name
    $vsphere_tag_env_category = $formData.vsphere_tag_env_category
    $vsphere_tag_backups_name = $formData.vsphere_tag_backups_name
    $vsphere_tag_backups_category = $formData.vsphere_tag_backups_category
    $vsphere_tag_application_name = $formData.vsphere_tag_application_name
    $vsphere_tag_application_category = $formData.vsphere_tag_application_category
    $vsphere_tag_application_owner_name = $formData.vsphere_tag_application_owner_name
    $vsphere_tag_application_owner_category = $formData.vsphere_tag_application_owner_category
    $vsphere_tag_os_category = $formData.vsphere_tag_os_category
    $vsphere_tag_os_name = $formData.vsphere_tag_os_name
    $change_request = $formData.change_request

    # Construct the .tfvars content dynamically using variables
    $tfvarsContent = @"
provider_vsphere_host = "$provider_vsphere_host"
deploy_vsphere_datacenter = "$deploy_vsphere_datacenter"
deploy_vsphere_cluster = "$deploy_vsphere_cluster"
deploy_vsphere_datastore = "$deploy_vsphere_datastore"
deploy_vsphere_network = "$deploy_vsphere_network"
deploy_vsphere_folder = "$deploy_vsphere_folder"
guest_template = "$guest_template"
guest_vm_name = "$guest_vm_name"
vsphere_vm_firmware = "$vsphere_vm_firmware"
guest_vcpu = "$guest_vcpu"
guest_memory = "$guest_memory"
guest_ipv4_addr = "$guest_ipv4_addr"
guest_ipv4_netmask = "$guest_ipv4_netmask"
guest_ipv4_gateway = "$guest_ipv4_gateway"
guest_dns_servers = "$guest_dns_servers"
guest_dns_servers2 = "$guest_dns_servers2"
guest_dns_suffix = "$guest_dns_suffix"
vsphere_tag_env_name = "$vsphere_tag_env_name"
vsphere_tag_backups_name = "$vsphere_tag_backups_name"
vsphere_tag_application_name = "$vsphere_tag_application_name"
vsphere_tag_env_category = "$vsphere_tag_env_category"
vsphere_tag_backups_category = "$vsphere_tag_backups_category"
vsphere_tag_application_category = "$vsphere_tag_application_category"
vsphere_tag_application_owner_name = "$vsphere_tag_application_owner_name"
vsphere_tag_application_owner_category = "$vsphere_tag_application_owner_category"
vsphere_tag_os_category = "$vsphere_tag_os_category"
vsphere_tag_os_name = "$vsphere_tag_os_name"
"@

    # Log the generated tfvars content for debugging
    Write-Host "Generated .tfvars content: $tfvarsContent"

    # Base64-encode the tfvars content for GitHub
    $tfvarsContentBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($tfvarsContent))

    # Extract fields for Github Payload
    $guest_vm_name = $formData.guest_vm_name
    $change_request = $formData.change_request

    # Construct GitHub payload
    $githubPayload = @{
        "event_type" = "vsphere_vm_deployment"
        "client_payload" = @{
            "guest_vm_name" = $guest_vm_name
            "tfvars_content" = $tfvarsContentBase64
            "change_request" = $change_request
        }
    } | ConvertTo-Json -Depth 10

    # Send POST request to GitHub
    try {
        $response = Invoke-RestMethod -Uri $githubWebhookUrl -Method Post -Headers @{
            "Authorization" = "Bearer $githubToken"
            "Content-Type" = "application/json"
        } -Body $githubPayload

        # Ensure we handle empty responses from GitHub API
        if (-not $response) {
            Write-Host "GitHub API returned no body, assuming success."
            $response = @{"status"="GitHub Dispatch Success"}
        }

        Write-Host "GitHub Dispatch Response: $($response | ConvertTo-Json -Depth 10)"
    } catch {
        Write-Host "Error calling GitHub API: $_"
    }

    # Return success response
    $Response = @{
        StatusCode = 200
        Body = '{"status":"success","message":"GitHub dispatch triggered"}'
        Headers = @{"Content-Type" = "application/json"}
    }
    Write-Host "Returning Success Response: $($Response | ConvertTo-Json -Depth 10)"

    return $Response

} catch {
    # Handle errors
    Write-Host "Error: $_"
    $Response = @{
        StatusCode = 400
        Body = "Error processing request: $_"
        Headers = @{"Content-Type" = "application/json"}
    }
    return $Response
}

# Ensure a response is always returned
if (-not $Response) {
    Write-Host "Warning: No response set, defaulting to success."
    $Response = @{
        StatusCode = 200
        Body = '{"status":"success","message":"GitHub dispatch triggered, but no response from API"}'
        Headers = @{"Content-Type" = "application/json"}
    }
}

Write-Host "Final Response: $($Response | ConvertTo-Json -Depth 10)"
return $Response