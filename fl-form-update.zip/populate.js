// populate.js
document.addEventListener("DOMContentLoaded", async function () {
  try {
    const response = await fetch("values.txt");
    if (!response.ok) {
      throw new Error("Failed to load values.txt");
    }
    const text = await response.text();

    // Parse the .txt file
    const lines = text.split("\n").map(line => line.trim());
    const values = {};
    let currentCategory = null;

    lines.forEach(line => {
      if (line.startsWith("#")) {
        currentCategory = line.slice(1); // Remove # and set category
        values[currentCategory] = [];
      } else if (currentCategory && line) {
        values[currentCategory].push(line); // Add value to current category
      }
    });

    // Populate dropdowns
    populateDropdown("provider_vsphere_host", values.vspheretarget); // New: vCenter Host
    populateDropdown("deploy_vsphere_datacenter", values.datacenters);
    populateDropdown("deploy_vsphere_cluster", values.clusters);
    populateDropdown("deploy_vsphere_datastore", values.datastores);
    populateDropdown("deploy_vsphere_folder", values.folders); // New: Folder
    populateDropdown("deploy_vsphere_network", values.networks);
    populateDropdown("guest_template", values.templates);
  } catch (error) {
    console.error("Error loading dropdown values:", error);
    alert("Failed to load dropdown options. Please ensure values.txt exists and the page is served via a server.");
  }
});

function populateDropdown(elementId, values) {
  const select = document.getElementById(elementId);
  if (!select || !values) return;

  values.forEach(value => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  });
}