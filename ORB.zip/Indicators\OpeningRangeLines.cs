using System;
using System.Windows.Media;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;

namespace NinjaTrader.NinjaScript.Indicators
{
    public class OpeningRangeLines : Indicator
    {
        private DateTime rangeStart;  // User-defined start time (e.g., 9:31 AM)
        private DateTime rangeEnd;    // User-defined end time (e.g., 9:45 AM)
        private DateTime sessionOpen; // NY session opening (configurable, default 9:30 AM)
        private DateTime nySessionEnd; // NY session end (configurable, default 4:00 PM)

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Plots high, low, and mid lines for a custom opening range period within NY session.";
                Name = "OpeningRangeLines";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                IsSuspendedWhileInactive = true;
                DrawOnPricePanel = true;

                NYSessionStartHour = 9;     // Default NY session start at 9:30 AM
                NYSessionStartMinute = 30;
                RangeStartHour = 9;
                RangeStartMinute = 31;      // Default range start at 9:31 AM
                RangeEndHour = 9;
                RangeEndMinute = 45;        // Default range end at 9:45 AM
                NYSessionEndHour = 16;      // Default NY session end at 4:00 PM
                NYSessionEndMinute = 0;

                // Define plots with fixed colors and styles
                AddPlot(new Stroke(Brushes.DodgerBlue, DashStyleHelper.Solid, 2), PlotStyle.Hash, "RangeHigh");
                AddPlot(new Stroke(Brushes.DodgerBlue, DashStyleHelper.Solid, 2), PlotStyle.Hash, "RangeLow");
                AddPlot(new Stroke(Brushes.Gray, DashStyleHelper.Dash, 2), PlotStyle.Hash, "RangeMid");
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 1) return;

            sessionOpen = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, NYSessionStartHour, NYSessionStartMinute, 0);
            rangeStart = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, RangeStartHour, RangeStartMinute, 0);
            rangeEnd = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, RangeEndHour, RangeEndMinute, 0);
            nySessionEnd = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, NYSessionEndHour, NYSessionEndMinute, 0);

            // Get the bar indices for rangeStart and rangeEnd
            int startBarIndex = Bars.GetBar(rangeStart);
            int endBarIndex = Bars.GetBar(rangeEnd);

            if (startBarIndex >= 0 && endBarIndex >= 0 && startBarIndex <= CurrentBar && endBarIndex <= CurrentBar)
            {
                double rangeHigh = double.MinValue;
                double rangeLow = double.MaxValue;

                // Iterate over all bars from rangeStart to rangeEnd
                for (int i = startBarIndex; i <= endBarIndex; i++)
                {
                    DateTime barStartTime = Bars.GetTime(i);
                    DateTime barEndTime = barStartTime.AddMinutes(Bars.BarsPeriod.Value).AddTicks(-1);

                    if (barEndTime >= rangeStart && barStartTime <= rangeEnd)
                    {
                        rangeHigh = Math.Max(rangeHigh, Bars.GetHigh(i));
                        rangeLow = Math.Min(rangeLow, Bars.GetLow(i));
                    }
                }

                double rangeMid = (rangeHigh + rangeLow) / 2;

                // Plot the values only within NY session
                if (Time[0] >= sessionOpen && Time[0] <= nySessionEnd)
                {
                    RangeHigh[0] = rangeHigh;
                    RangeLow[0] = rangeLow;
                    RangeMid[0] = rangeMid;
                }
                else
                {
                    RangeHigh[0] = double.NaN;
                    RangeLow[0] = double.NaN;
                    RangeMid[0] = double.NaN;
                }

                Print($"Bar Time: {Time[0]}, Start Index: {startBarIndex}, End Index: {endBarIndex}, High: {rangeHigh}, Low: {rangeLow}, Mid: {rangeMid}");
            }
            else
            {
                RangeHigh[0] = double.NaN;
                RangeLow[0] = double.NaN;
                RangeMid[0] = double.NaN;
            }
        }

        #region Properties
        [Browsable(false)]
        [XmlIgnore]
        public Series<double> RangeHigh
        {
            get { return Values[0]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> RangeLow
        {
            get { return Values[1]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> RangeMid
        {
            get { return Values[2]; }
        }

        [NinjaScriptProperty]
        [Range(0, 23)]
        [Display(Name = "NY Session Start Hour", Description = "Hour to start NY session (0-23)", Order = 1, GroupName = "Parameters")]
        public int NYSessionStartHour { get; set; }

        [NinjaScriptProperty]
        [Range(0, 59)]
        [Display(Name = "NY Session Start Minute", Description = "Minute to start NY session (0-59)", Order = 2, GroupName = "Parameters")]
        public int NYSessionStartMinute { get; set; }

        [NinjaScriptProperty]
        [Range(0, 23)]
        [Display(Name = "Range Start Hour", Description = "Hour to start range period (0-23)", Order = 3, GroupName = "Parameters")]
        public int RangeStartHour { get; set; }

        [NinjaScriptProperty]
        [Range(0, 59)]
        [Display(Name = "Range Start Minute", Description = "Minute to start range period (0-59)", Order = 4, GroupName = "Parameters")]
        public int RangeStartMinute { get; set; }

        [NinjaScriptProperty]
        [Range(0, 23)]
        [Display(Name = "Range End Hour", Description = "Hour to end range period (0-23)", Order = 5, GroupName = "Parameters")]
        public int RangeEndHour { get; set; }

        [NinjaScriptProperty]
        [Range(0, 59)]
        [Display(Name = "Range End Minute", Description = "Minute to end range period (0-59)", Order = 6, GroupName = "Parameters")]
        public int RangeEndMinute { get; set; }

        [NinjaScriptProperty]
        [Range(0, 23)]
        [Display(Name = "NY Session End Hour", Description = "Hour to end NY session (0-23)", Order = 7, GroupName = "Parameters")]
        public int NYSessionEndHour { get; set; }

        [NinjaScriptProperty]
        [Range(0, 59)]
        [Display(Name = "NY Session End Minute", Description = "Minute to end NY session (0-59)", Order = 8, GroupName = "Parameters")]
        public int NYSessionEndMinute { get; set; }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private OpeningRangeLines[] cacheOpeningRangeLines;
		public OpeningRangeLines OpeningRangeLines(int nYSessionStartHour, int nYSessionStartMinute, int rangeStartHour, int rangeStartMinute, int rangeEndHour, int rangeEndMinute, int nYSessionEndHour, int nYSessionEndMinute)
		{
			return OpeningRangeLines(Input, nYSessionStartHour, nYSessionStartMinute, rangeStartHour, rangeStartMinute, rangeEndHour, rangeEndMinute, nYSessionEndHour, nYSessionEndMinute);
		}

		public OpeningRangeLines OpeningRangeLines(ISeries<double> input, int nYSessionStartHour, int nYSessionStartMinute, int rangeStartHour, int rangeStartMinute, int rangeEndHour, int rangeEndMinute, int nYSessionEndHour, int nYSessionEndMinute)
		{
			if (cacheOpeningRangeLines != null)
				for (int idx = 0; idx < cacheOpeningRangeLines.Length; idx++)
					if (cacheOpeningRangeLines[idx] != null && cacheOpeningRangeLines[idx].NYSessionStartHour == nYSessionStartHour && cacheOpeningRangeLines[idx].NYSessionStartMinute == nYSessionStartMinute && cacheOpeningRangeLines[idx].RangeStartHour == rangeStartHour && cacheOpeningRangeLines[idx].RangeStartMinute == rangeStartMinute && cacheOpeningRangeLines[idx].RangeEndHour == rangeEndHour && cacheOpeningRangeLines[idx].RangeEndMinute == rangeEndMinute && cacheOpeningRangeLines[idx].NYSessionEndHour == nYSessionEndHour && cacheOpeningRangeLines[idx].NYSessionEndMinute == nYSessionEndMinute && cacheOpeningRangeLines[idx].EqualsInput(input))
						return cacheOpeningRangeLines[idx];
			return CacheIndicator<OpeningRangeLines>(new OpeningRangeLines(){ NYSessionStartHour = nYSessionStartHour, NYSessionStartMinute = nYSessionStartMinute, RangeStartHour = rangeStartHour, RangeStartMinute = rangeStartMinute, RangeEndHour = rangeEndHour, RangeEndMinute = rangeEndMinute, NYSessionEndHour = nYSessionEndHour, NYSessionEndMinute = nYSessionEndMinute }, input, ref cacheOpeningRangeLines);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.OpeningRangeLines OpeningRangeLines(int nYSessionStartHour, int nYSessionStartMinute, int rangeStartHour, int rangeStartMinute, int rangeEndHour, int rangeEndMinute, int nYSessionEndHour, int nYSessionEndMinute)
		{
			return indicator.OpeningRangeLines(Input, nYSessionStartHour, nYSessionStartMinute, rangeStartHour, rangeStartMinute, rangeEndHour, rangeEndMinute, nYSessionEndHour, nYSessionEndMinute);
		}

		public Indicators.OpeningRangeLines OpeningRangeLines(ISeries<double> input , int nYSessionStartHour, int nYSessionStartMinute, int rangeStartHour, int rangeStartMinute, int rangeEndHour, int rangeEndMinute, int nYSessionEndHour, int nYSessionEndMinute)
		{
			return indicator.OpeningRangeLines(input, nYSessionStartHour, nYSessionStartMinute, rangeStartHour, rangeStartMinute, rangeEndHour, rangeEndMinute, nYSessionEndHour, nYSessionEndMinute);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.OpeningRangeLines OpeningRangeLines(int nYSessionStartHour, int nYSessionStartMinute, int rangeStartHour, int rangeStartMinute, int rangeEndHour, int rangeEndMinute, int nYSessionEndHour, int nYSessionEndMinute)
		{
			return indicator.OpeningRangeLines(Input, nYSessionStartHour, nYSessionStartMinute, rangeStartHour, rangeStartMinute, rangeEndHour, rangeEndMinute, nYSessionEndHour, nYSessionEndMinute);
		}

		public Indicators.OpeningRangeLines OpeningRangeLines(ISeries<double> input , int nYSessionStartHour, int nYSessionStartMinute, int rangeStartHour, int rangeStartMinute, int rangeEndHour, int rangeEndMinute, int nYSessionEndHour, int nYSessionEndMinute)
		{
			return indicator.OpeningRangeLines(input, nYSessionStartHour, nYSessionStartMinute, rangeStartHour, rangeStartMinute, rangeEndHour, rangeEndMinute, nYSessionEndHour, nYSessionEndMinute);
		}
	}
}

#endregion
