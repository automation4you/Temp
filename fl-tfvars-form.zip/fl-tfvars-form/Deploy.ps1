﻿Add-Type -AssemblyName System.Windows.Forms

# Set the Windows 11-like font
$font = New-Object System.Drawing.Font("Segoe UI", 10)

# Create the form (dark theme)
$form = New-Object System.Windows.Forms.Form
$form.Text = "Docker Compose Setup"
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$form.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40)  # Dark background
$form.ForeColor = [System.Drawing.Color]::White  # Light text color
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
$form.MaximizeBox = $false
$form.MinimizeBox = $false

# Create a FlowLayoutPanel to automatically arrange controls
$flowLayoutPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$flowLayoutPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$flowLayoutPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
$flowLayoutPanel.WrapContents = $false
$flowLayoutPanel.AutoScroll = $true
$flowLayoutPanel.Padding = New-Object System.Windows.Forms.Padding(10)  # Add padding on all sides
$form.Controls.Add($flowLayoutPanel)

# SECRET input
$labelSecret = New-Object System.Windows.Forms.Label
$labelSecret.Text = "Enter SECRET:"
$labelSecret.AutoSize = $true  # Allow the label to auto-size based on content
$labelSecret.Font = $font
$labelSecret.ForeColor = [System.Drawing.Color]::White
$flowLayoutPanel.Controls.Add($labelSecret)

$passwordBoxSecret = New-Object System.Windows.Forms.TextBox
$passwordBoxSecret.Size = New-Object System.Drawing.Size(250, 20)
$passwordBoxSecret.PasswordChar = '*'  # Hide input
$passwordBoxSecret.Font = $font
$passwordBoxSecret.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)  # Dark input field
$passwordBoxSecret.ForeColor = [System.Drawing.Color]::White
$passwordBoxSecret.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle  # Flat border
$flowLayoutPanel.Controls.Add($passwordBoxSecret)

# GITHUB_URL input
$labelGithubUrl = New-Object System.Windows.Forms.Label
$labelGithubUrl.Text = "Enter GITHUB_URL:"
$labelGithubUrl.AutoSize = $true  # Allow the label to auto-size based on content
$labelGithubUrl.Font = $font
$labelGithubUrl.ForeColor = [System.Drawing.Color]::White
$flowLayoutPanel.Controls.Add($labelGithubUrl)

$textBoxGithubUrl = New-Object System.Windows.Forms.TextBox
$textBoxGithubUrl.Size = New-Object System.Drawing.Size(250, 20)
$textBoxGithubUrl.Font = $font
$textBoxGithubUrl.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)  # Dark input field
$textBoxGithubUrl.ForeColor = [System.Drawing.Color]::White
$textBoxGithubUrl.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle  # Flat border
$flowLayoutPanel.Controls.Add($textBoxGithubUrl)

# GITHUB_TOKEN input (hidden)
$labelGithubToken = New-Object System.Windows.Forms.Label
$labelGithubToken.Text = "Enter GITHUB_TOKEN:"
$labelGithubToken.AutoSize = $true  # Allow the label to auto-size based on content
$labelGithubToken.Font = $font
$labelGithubToken.ForeColor = [System.Drawing.Color]::White
$flowLayoutPanel.Controls.Add($labelGithubToken)

$passwordBoxGithubToken = New-Object System.Windows.Forms.TextBox
$passwordBoxGithubToken.Size = New-Object System.Drawing.Size(250, 20)
$passwordBoxGithubToken.PasswordChar = '*'  # Hide input
$passwordBoxGithubToken.Font = $font
$passwordBoxGithubToken.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)  # Dark input field
$passwordBoxGithubToken.ForeColor = [System.Drawing.Color]::White
$passwordBoxGithubToken.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle  # Flat border
$flowLayoutPanel.Controls.Add($passwordBoxGithubToken)

# Button to start Docker Compose
$buttonStart = New-Object System.Windows.Forms.Button
$buttonStart.Text = "Start Docker Compose"
$buttonStart.Size = New-Object System.Drawing.Size(150, 30)
$buttonStart.Font = $font
$buttonStart.BackColor = [System.Drawing.Color]::FromArgb(38, 78, 112)  # Accent blue for button
$buttonStart.ForeColor = [System.Drawing.Color]::White
$buttonStart.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$buttonStart.FlatAppearance.BorderSize = 0
$flowLayoutPanel.Controls.Add($buttonStart)

# Progress Bar
$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Size = New-Object System.Drawing.Size(250, 20)
$progressBar.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
$progressBar.Minimum = 0
$progressBar.Maximum = 100
$flowLayoutPanel.Controls.Add($progressBar)

# Button click action
$buttonStart.Add_Click({
    $secret = $passwordBoxSecret.Text
    $githubUrl = $textBoxGithubUrl.Text
    $githubToken = $passwordBoxGithubToken.Text

    # Set the environment variables
    $env:SECRET = $secret
    $env:GITHUB_URL = $githubUrl
    $env:GITHUB_TOKEN = $githubToken

    # Simulate progress bar updates and run docker-compose
    $progressBar.Value = 0
    $progressBar.Visible = $true
    for ($i = 1; $i -le 100; $i++) {
        Start-Sleep -Milliseconds 50
        $progressBar.Value = $i
    }

    # Run docker-compose
    Write-Host "Starting Docker Compose..."
    $dockerComposeCmd = "docker-compose up --build -d"
    $process = Start-Process -FilePath "docker-compose" -ArgumentList "up --build -d" -PassThru -RedirectStandardError "stderr.log" -Wait

    # Check the exit code of the process
    if ($process.ExitCode -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Docker Compose started successfully.", "Success", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    } else {
        [System.Windows.Forms.MessageBox]::Show("Failed to start Docker Compose. Check stderr.log for errors.", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
})

# Show the form
$form.ShowDialog()
