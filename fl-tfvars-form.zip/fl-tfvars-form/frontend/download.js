// download.js
document.getElementById("downloadBtn").addEventListener("click", function () {
  const formData = new FormData(document.getElementById("payloadForm"));
  let tfvarsData = {};
  let allFieldsFilled = true;
  let changeRequestValue = "";
  const ipFields = [
    "guest_ipv4_addr",
    "guest_ipv4_netmask",
    "guest_ipv4_gateway",
    "guest_dns_servers",
    "guest_dns_servers2"
  ];

  formData.forEach((value, key) => {
    if (value.trim() === "") {
      allFieldsFilled = false;
    }
    if (key === "change_request") {
      changeRequestValue = value;
    } else {
      tfvarsData[key] = value;
    }
  });

  if (!allFieldsFilled) {
    alert("All fields must be filled out before downloading.");
    return;
  }

  let isValid = true;
  for (const field of ipFields) {
    if (!isValidIPv4(tfvarsData[field])) {
      isValid = false;
      break;
    }
  }

  if (!isValid) {
    alert("IP Address, Netmask, Gateway, and DNS fields must be in the format x.x.x.x (e.g., 192.168.1.1).");
    return;
  }

  const guestVmName = tfvarsData["guest_vm_name"] || "default_vm";
  let tfvarsContent = `#change_request = "${changeRequestValue}"\n`;

  for (const [key, value] of Object.entries(tfvarsData)) {
    tfvarsContent += `${key} = "${value}"\n`;
  }

  const blob = new Blob([tfvarsContent], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${guestVmName}.tfvars`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
});