// submit.js
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("payloadForm");
  const submitBtn = document.getElementById("submitBtn");

  form.addEventListener("submit", async function (event) {
    event.preventDefault();
    const formData = new FormData(form);
    const jsonData = {};
    const ipFields = [
      "guest_ipv4_addr",
      "guest_ipv4_netmask",
      "guest_ipv4_gateway",
      "guest_dns_servers",
      "guest_dns_servers2"
    ];

    let isValid = true;
    formData.forEach((value, key) => {
      jsonData[key] = value;
      if (ipFields.includes(key) && !isValidIPv4(value)) {
        isValid = false;
      }
    });

    if (!isValid) {
      alert("IP Address, Netmask, Gateway, and DNS fields must be in the format x.x.x.x (e.g., 192.168.1.1).");
      return;
    }

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = "Submitting...";

      const response = await fetch("/submit-form", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(jsonData),
      });

      if (!response.ok) {
        throw new Error("Failed to submit form. Please try again.");
      }

      const result = await response.json();
      if (result.status === "success") {
        alert("Form submitted successfully to GitHub!");
      } else {
        alert("Form submission succeeded but no success status received.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Error submitting form.");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Send to Github";
    }
  });
});