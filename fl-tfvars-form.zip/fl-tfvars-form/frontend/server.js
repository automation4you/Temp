const express = require('express');
const fetch = require('node-fetch');

const app = express();
app.use(express.json());

// Use environment variable for the secret token
const SECRET_TOKEN = process.env.SECRET || 'default-secret'; // Fallback for testing

// Endpoint to handle form submission and forward it
app.post('/submit-form', async (req, res) => {
  const payload = req.body;

  try {
    const response = await fetch('http://fl-ps-azure-func:80/api/tfvars-parser', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'form-signature': SECRET_TOKEN // Use the env var here
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error('Failed to forward request to Azure Function');
    }

    let data;
    try {
      data = await response.json();
    } catch (error) {
      data = { status: "error", message: "Azure Function returned invalid JSON." };
    }

    res.json(data); // Send the JSON response back to the client
  } catch (error) {
    console.error('Error forwarding request:', error);
    res.status(500).json({ status: "error", message: "Error forwarding request: " + error.message });
  }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));